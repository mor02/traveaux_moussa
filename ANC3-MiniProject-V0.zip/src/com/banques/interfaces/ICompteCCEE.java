package com.banques.interfaces;

public interface ICompteCCEE {

	public boolean retirer(double montant);
}
